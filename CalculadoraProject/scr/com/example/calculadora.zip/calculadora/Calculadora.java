package CalculadoraProject.scr.com.example.calculadora;

public interface Calculadora {
    double calcular(double a, double b);
}
