package CalculadoraProject.scr.com.example.calculadora;

public class Subtracao implements Calculadora {
    @Override
    public double calcular(double a, double b) {
        return a - b;
    }
}